import { NextRequest, NextResponse } from "next/server";

const PUBLIC_ROUTES = ["/auth/login", "/auth/register"];

// Rate limiting simple en memoria (por IP)
const loginAttempts = new Map<string, { count: number; resetAt: number }>();

function checkRateLimit(ip: string): boolean {
  const now = Date.now();
  const entry = loginAttempts.get(ip);

  if (!entry || now > entry.resetAt) {
    loginAttempts.set(ip, { count: 1, resetAt: now + 60_000 }); // ventana 1 min
    return true;
  }

  if (entry.count >= 10) return false; // max 10 intentos/min

  entry.count++;
  return true;
}

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  // Siempre permitir auth API
  if (pathname.startsWith("/api/auth")) {
    // Rate limit en login
    if (pathname.includes("/sign-in") || pathname.includes("/login")) {
      const ip = request.headers.get("x-forwarded-for")?.split(",")[0] || "unknown";
      if (!checkRateLimit(ip)) {
        return new NextResponse("Demasiados intentos. Espera 1 minuto.", {
          status: 429,
          headers: { "Retry-After": "60" },
        });
      }
    }
    return NextResponse.next();
  }

  // Rutas públicas
  if (PUBLIC_ROUTES.some((r) => pathname.startsWith(r))) {
    return NextResponse.next();
  }

  // Archivos estáticos de uploads — protegidos por la API route que tiene su propia auth
  if (pathname.startsWith("/api/files")) {
    return NextResponse.next();
  }

  // Verificar sesión
  const sessionToken =
    request.cookies.get("better-auth.session_token")?.value ||
    request.cookies.get("__Secure-better-auth.session_token")?.value;

  // Redirigir a login si no hay sesión en páginas
  if (!sessionToken && !pathname.startsWith("/api/")) {
    return NextResponse.redirect(new URL("/auth/login", request.url));
  }

  // Bloquear rutas API sin sesión (devuelve 401 en vez de redirigir)
  if (!sessionToken && pathname.startsWith("/api/")) {
    return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  }

  // Añadir cabeceras de seguridad a todas las respuestas
  const response = NextResponse.next();

  response.headers.set("X-Frame-Options", "DENY");
  response.headers.set("X-Content-Type-Options", "nosniff");
  response.headers.set("Referrer-Policy", "strict-origin-when-cross-origin");
  response.headers.set("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
  response.headers.set(
    "Strict-Transport-Security",
    "max-age=31536000; includeSubDomains"
  );

  return response;
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|.*\.jpg|.*\.jpeg|.*\.png|.*\.gif|.*\.svg|.*\.ico|.*\.webp|.*\.riv).*)"],
};