"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import { useSession } from "@/lib/auth-client";
import { Avatar } from "@/components/ui/Avatar";

interface Usuario { id: string; name: string; image?: string | null; }
interface MensajeData {
  id: string; contenido: string; autorId: string; leidoPor: string[];
  creadoEn: string; autor?: { name: string; image?: string | null };
}
interface ConvData {
  id: string; tipo: string; participantes: string[];
  ultimoMensaje?: { contenido: string; creadoEn: string; autorId: string; leidoPor: string[] } | null;
  noLeidos: number;
}

function formatHora(iso: string) {
  return new Date(iso).toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" });
}
function formatFechaSep(iso: string) {
  const d = new Date(iso);
  const hoy = new Date(); hoy.setHours(0, 0, 0, 0);
  const ayer = new Date(hoy); ayer.setDate(hoy.getDate() - 1);
  const fecha = new Date(d); fecha.setHours(0, 0, 0, 0);
  if (fecha.getTime() === hoy.getTime()) return "Hoy";
  if (fecha.getTime() === ayer.getTime()) return "Ayer";
  return d.toLocaleDateString("es-ES", { weekday: "long", day: "numeric", month: "long" });
}
function agruparPorFecha(mensajes: MensajeData[]) {
  const grupos: { fecha: string; items: MensajeData[] }[] = [];
  mensajes.forEach(m => {
    const d = new Date(m.creadoEn); d.setHours(0, 0, 0, 0);
    const key = d.toISOString();
    const ultimo = grupos[grupos.length - 1];
    if (ultimo && ultimo.fecha === key) ultimo.items.push(m);
    else grupos.push({ fecha: key, items: [m] });
  });
  return grupos;
}

export function ChatWidget() {
  const { data: session } = useSession();
  const miId = (session?.user as any)?.id;

  const [abierto, setAbierto] = useState(false);
  const [vistaLista, setVistaLista] = useState(true);
  const [usuarios, setUsuarios] = useState<Usuario[]>([]);
  const [conversaciones, setConversaciones] = useState<ConvData[]>([]);
  const [activa, setActiva] = useState<{ tipo: "general" | "privada"; conUsuario?: string } | null>(null);
  const [mensajes, setMensajes] = useState<MensajeData[]>([]);
  const [texto, setTexto] = useState("");
  const [enviando, setEnviando] = useState(false);
  const [totalNoLeidos, setTotalNoLeidos] = useState(0);
  const bottomRef = useRef<HTMLDivElement>(null);
  const ultimoRef = useRef<string | null>(null);
  const pollingRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const mensajesLen = useRef(0);
  mensajesLen.current = mensajes.length;

  const cargarLista = useCallback(async () => {
    try {
      const r = await fetch("/api/chat?tipo=lista");
      if (!r.ok) return;
      const d = await r.json();
      const convs = d.conversaciones || [];
      setConversaciones(convs);
      setUsuarios(d.usuarios || []);
      setTotalNoLeidos(convs.reduce((s: number, c: any) => s + (c.noLeidos || 0), 0));
    } catch { }
  }, []);

  const cargarMensajes = useCallback(async (resetear = false) => {
    if (!activa) return;
    const params = new URLSearchParams();
    if (activa.tipo === "general") params.set("tipo", "general");
    else if (activa.conUsuario) params.set("conUsuario", activa.conUsuario);
    else return;
    if (!resetear && ultimoRef.current && mensajesLen.current > 0)
      params.set("desde", ultimoRef.current);
    try {
      const r = await fetch(`/api/chat?${params}`);
      if (!r.ok) return;
      const d = await r.json();
      if (resetear) {
        setMensajes(d.mensajes || []);
      } else if (d.mensajes?.length > 0) {
        setMensajes(prev => {
          const ids = new Set(prev.map((m: MensajeData) => m.id));
          const nuevos = d.mensajes.filter((m: MensajeData) => !ids.has(m.id));
          return nuevos.length > 0 ? [...prev, ...nuevos] : prev;
        });
      }
      if (d.mensajes?.length > 0) ultimoRef.current = d.mensajes[d.mensajes.length - 1].creadoEn;
      cargarLista();
    } catch { }
  }, [activa, cargarLista]);

  useEffect(() => {
    if (!session) return;
    cargarLista();
    const i = setInterval(() => { if (!abierto) cargarLista(); }, 15000);
    return () => clearInterval(i);
  }, [session]);

  useEffect(() => {
    if (!activa) return;
    setMensajes([]); ultimoRef.current = null;
    cargarMensajes(true);
    if (pollingRef.current) clearInterval(pollingRef.current);
    pollingRef.current = setInterval(() => cargarMensajes(false), 10000);
    return () => { if (pollingRef.current) clearInterval(pollingRef.current); };
  }, [activa?.tipo, activa?.conUsuario]);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [mensajes]);

  async function enviar() {
    if (!texto.trim() || enviando || !activa) return;
    setEnviando(true);
    const body: any = { contenido: texto, tipo: activa.tipo };
    if (activa.conUsuario) body.conUsuario = activa.conUsuario;
    try {
      const r = await fetch("/api/chat", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      if (r.ok) { setTexto(""); await cargarMensajes(false); }
    } catch { }
    setEnviando(false);
  }

  function abrirConv(conv: { tipo: "general" | "privada"; conUsuario?: string }) {
    setActiva(conv); setVistaLista(false);
  }

  const getUsuario = (id: string) => usuarios.find(u => u.id === id);
  const convGeneral = conversaciones.find(c => c.tipo === "general");
  const grupos = agruparPorFecha(mensajes);
  const nombreActiva = activa?.tipo === "general" ? "Sala general" : getUsuario(activa?.conUsuario || "")?.name || "";

  if (!session) return null;

  return (
    <>
      {abierto && (
        <div style={{
          position: "fixed", bottom: 88, right: 24, zIndex: 9999,
          width: 720, height: 520, borderRadius: 20, overflow: "hidden",
          boxShadow: "0 20px 60px rgba(0,0,0,0.2),0 4px 20px rgba(0,0,0,0.1)",
          display: "flex", border: "1px solid #e0e0e0", background: "white",
          animation: "chatPop 0.25s cubic-bezier(0.34,1.56,0.64,1)",
        }}>
          {/* Lista */}
          <div style={{
            width: vistaLista ? "100%" : 210, flexShrink: 0,
            borderRight: "1px solid #f0f0f0",
            display: "flex", flexDirection: "column", background: "#f8f8f8",
            transition: "width 0.2s ease",
          }}>
            <div style={{
              padding: "12px 14px 10px", borderBottom: "1px solid #ebebeb",
              display: "flex", alignItems: "center", justifyContent: "space-between"
            }}>
              <h3 style={{
                fontFamily: "var(--font-playfair)", fontWeight: 800, fontSize: 15,
                color: "#0f0f0f", display: "flex", alignItems: "center", gap: 8
              }}>
                <span style={{ width: 3, height: 14, background: "#cc1111", borderRadius: 4, display: "block" }} />
                {vistaLista ? "Mensajes" : ""}
              </h3>
              <button onClick={() => setAbierto(false)}
                style={{
                  width: 24, height: 24, borderRadius: "50%", border: "none",
                  background: "#e8e8e8", cursor: "pointer", fontSize: 11, color: "#666",
                  display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0
                }}>✕</button>
            </div>
            <div style={{ flex: 1, overflowY: "auto", padding: "6px 8px" }}>
              <p style={{
                fontSize: 9, fontWeight: 700, color: "#bbb", textTransform: "uppercase",
                letterSpacing: "0.1em", padding: "4px 6px 4px"
              }}>General</p>
              <ConvItem nombre="Sala general"
                sub={convGeneral?.ultimoMensaje?.contenido || "Sin mensajes aún"}
                emoji="🌐"
                activa={!vistaLista && activa?.tipo === "general"}
                noLeidos={convGeneral?.noLeidos || 0}
                hora={convGeneral?.ultimoMensaje?.creadoEn}
                mini={!vistaLista}
                onClick={() => abrirConv({ tipo: "general" })} />
              <p style={{
                fontSize: 9, fontWeight: 700, color: "#bbb", textTransform: "uppercase",
                letterSpacing: "0.1em", padding: "8px 6px 4px"
              }}>Directos</p>
              {usuarios.filter(u => u.id !== miId).map(u => {
                const conv = conversaciones.find(c =>
                  c.tipo === "privada" && c.participantes.includes(u.id) && c.participantes.includes(miId));
                return (
                  <ConvItem key={u.id} nombre={u.name}
                    sub={conv?.ultimoMensaje?.contenido || "Iniciar conversación"}
                    imagen={u.image}
                    activa={!vistaLista && activa?.tipo === "privada" && activa.conUsuario === u.id}
                    noLeidos={conv?.noLeidos || 0}
                    hora={conv?.ultimoMensaje?.creadoEn}
                    mini={!vistaLista}
                    onClick={() => abrirConv({ tipo: "privada", conUsuario: u.id })} />
                );
              })}
            </div>
          </div>

          {/* Mensajes */}
          {!vistaLista && activa && (
            <div style={{ flex: 1, display: "flex", flexDirection: "column", minWidth: 0 }}>
              <div style={{
                padding: "10px 14px", borderBottom: "1px solid #f0f0f0",
                background: "white", display: "flex", alignItems: "center", gap: 8
              }}>
                <button onClick={() => setVistaLista(true)}
                  style={{
                    width: 26, height: 26, borderRadius: "50%", border: "none",
                    background: "#f4f4f4", cursor: "pointer", fontSize: 13,
                    display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0
                  }}>←</button>
                {activa.tipo === "general" ? (
                  <div style={{
                    width: 32, height: 32, borderRadius: "50%", flexShrink: 0,
                    background: "linear-gradient(135deg,#cc1111,#ff6b6b)",
                    display: "flex", alignItems: "center", justifyContent: "center", fontSize: 15
                  }}>🌐</div>
                ) : (
                  <Avatar name={getUsuario(activa.conUsuario || "")?.name || "?"}
                    image={getUsuario(activa.conUsuario || "")?.image} size={32} round />
                )}
                <div style={{ minWidth: 0, flex: 1 }}>
                  <p style={{
                    fontWeight: 700, fontSize: 13, color: "#0f0f0f",
                    whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis"
                  }}>{nombreActiva}</p>
                  <p style={{ fontSize: 10, color: "#9ca3af" }}>
                    {activa.tipo === "general" ? `${usuarios.length} participantes` : "Privado"}
                  </p>
                </div>
              </div>

              <div style={{
                flex: 1, overflowY: "auto", padding: "10px 12px",
                backgroundImage: "radial-gradient(#e8e8e8 1px,transparent 1px)",
                backgroundSize: "20px 20px", backgroundColor: "#fdfdfd"
              }}>
                {mensajes.length === 0 && (
                  <div style={{
                    display: "flex", alignItems: "center", justifyContent: "center",
                    flexDirection: "column", gap: 8, color: "#9ca3af", paddingTop: 40
                  }}>
                    <span style={{ fontSize: 28 }}>💬</span>
                    <p style={{ fontSize: 12 }}>Sin mensajes aún</p>
                  </div>
                )}
                {grupos.map(grupo => (
                  <div key={grupo.fecha}>
                    <div style={{ display: "flex", alignItems: "center", gap: 8, margin: "8px 0" }}>
                      <div style={{ flex: 1, height: 1, background: "#e0e0e0" }} />
                      <span style={{
                        fontSize: 9, fontWeight: 600, color: "#9ca3af",
                        background: "white", padding: "2px 8px", borderRadius: 99,
                        border: "1px solid #e8e8e8", whiteSpace: "nowrap"
                      }}>
                        {formatFechaSep(grupo.fecha)}
                      </span>
                      <div style={{ flex: 1, height: 1, background: "#e0e0e0" }} />
                    </div>
                    {grupo.items.map((m, i) => {
                      const esMio = m.autorId === miId;
                      const mismoAntes = i > 0 && grupo.items[i - 1].autorId === m.autorId;
                      const mismoDespues = i < grupo.items.length - 1 && grupo.items[i + 1].autorId === m.autorId;
                      const todosLeidos = activa.tipo === "privada" && (m.leidoPor?.length || 0) > 1;
                      const brM = mismoAntes && mismoDespues ? "14px 3px 3px 14px" : mismoAntes ? "14px 3px 14px 14px" : mismoDespues ? "14px 14px 3px 14px" : "14px 14px 3px 14px";
                      const brO = mismoAntes && mismoDespues ? "3px 14px 14px 3px" : mismoAntes ? "3px 14px 14px 14px" : mismoDespues ? "3px 14px 3px 3px" : "3px 14px 14px 14px";
                      return (
                        <div key={m.id} style={{
                          display: "flex", flexDirection: "column",
                          alignItems: esMio ? "flex-end" : "flex-start", marginBottom: mismoDespues ? 2 : 5
                        }}>
                          {!esMio && !mismoAntes && activa.tipo === "general" && (
                            <span style={{ fontSize: 10, fontWeight: 700, color: "#555", marginBottom: 2, marginLeft: 28 }}>
                              {m.autor?.name}
                            </span>
                          )}
                          <div style={{
                            display: "flex", alignItems: "flex-end", gap: 5,
                            flexDirection: esMio ? "row-reverse" : "row"
                          }}>
                            {!esMio && (
                              <div style={{ width: 24, flexShrink: 0 }}>
                                {!mismoDespues && <Avatar name={m.autor?.name || "?"} image={m.autor?.image} size={24} round />}
                              </div>
                            )}
                            <div style={{ maxWidth: "78%" }}>
                              <div style={{
                                padding: "8px 13px",
                                borderRadius: esMio ? brM : brO,
                                background: esMio ? "linear-gradient(135deg,#cc1111,#e53333)" : "white",
                                color: esMio ? "white" : "#111",
                                border: esMio ? "none" : "1px solid #eee",
                                boxShadow: esMio ? "0 2px 8px rgba(204,17,17,0.2)" : "0 1px 4px rgba(0,0,0,0.06)",
                                fontSize: 13, lineHeight: 1.55,
                                wordBreak: "break-word",
                                overflowWrap: "break-word",
                                display: "inline-block",
                                width: "100%",
                                boxSizing: "border-box"
                              }}>
                                {m.contenido}
                              </div>
                              {!mismoDespues && (
                                <div style={{
                                  display: "flex", alignItems: "center", gap: 3,
                                  marginTop: 2, fontSize: 9, color: "#bbb",
                                  justifyContent: esMio ? "flex-end" : "flex-start"
                                }}>
                                  <span>{formatHora(m.creadoEn)}</span>
                                  {esMio && <span style={{ color: todosLeidos ? "#3b82f6" : "#ccc", fontWeight: 700 }}>
                                    {todosLeidos ? "✓✓" : "✓"}
                                  </span>}
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ))}
                <div ref={bottomRef} />
              </div>

              <div style={{
                padding: "8px 10px", borderTop: "1px solid #f0f0f0",
                background: "white", display: "flex", gap: 8, alignItems: "flex-end"
              }}>
                <textarea value={texto} onChange={e => setTexto(e.target.value)}
                  onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); enviar(); } }}
                  placeholder="Mensaje... (Enter)" rows={1}
                  style={{
                    flex: 1, resize: "none", border: "1.5px solid #e0e0e8", borderRadius: 14,
                    padding: "7px 11px", fontSize: 12, fontFamily: "inherit", outline: "none",
                    lineHeight: 1.5, maxHeight: 70, overflowY: "auto", background: "#fafafa",
                    transition: "all 0.15s", boxSizing: "border-box"
                  }}
                  onFocus={e => { (e.target as HTMLElement).style.borderColor = "#cc1111"; (e.target as HTMLElement).style.background = "white"; }}
                  onBlur={e => { (e.target as HTMLElement).style.borderColor = "#e0e0e8"; (e.target as HTMLElement).style.background = "#fafafa"; }} />
                <button onClick={enviar} disabled={enviando || !texto.trim()}
                  style={{
                    width: 34, height: 34, borderRadius: "50%", flexShrink: 0,
                    background: texto.trim() ? "linear-gradient(135deg,#cc1111,#e53333)" : "#f0f0f0",
                    border: "none", cursor: texto.trim() ? "pointer" : "default",
                    display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14,
                    transition: "all 0.2s", boxShadow: texto.trim() ? "0 2px 8px rgba(204,17,17,0.3)" : "none"
                  }}>
                  {enviando ? "⏳" : "➤"}
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Botón flotante */}
      <button onClick={() => { setAbierto(p => { if (!p) setVistaLista(true); return !p; }); }}
        style={{
          position: "fixed", bottom: 24, right: 24, zIndex: 10000,
          width: 54, height: 54, borderRadius: "50%",
          background: "linear-gradient(135deg,#cc1111,#e53333)",
          border: "none", cursor: "pointer",
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: 22, boxShadow: "0 6px 20px rgba(204,17,17,0.4)",
          transition: "all 0.2s",
          transform: abierto ? "scale(0.95)" : "scale(1)",
        }}
        onMouseEnter={e => (e.currentTarget as HTMLElement).style.transform = "scale(1.08)"}
        onMouseLeave={e => (e.currentTarget as HTMLElement).style.transform = abierto ? "scale(0.95)" : "scale(1)"}>
        {abierto ? "✕" : "💬"}
        {!abierto && totalNoLeidos > 0 && (
          <span style={{
            position: "absolute", top: -3, right: -3,
            minWidth: 19, height: 19, borderRadius: 99,
            background: "white", color: "#cc1111",
            fontSize: 9, fontWeight: 800,
            display: "flex", alignItems: "center", justifyContent: "center",
            padding: "0 4px", border: "2px solid white",
            boxShadow: "0 2px 6px rgba(0,0,0,0.2)"
          }}>
            {totalNoLeidos}
          </span>
        )}
      </button>

      <style>{`
        @keyframes chatPop {
          from{opacity:0;transform:scale(0.92) translateY(16px);}
          to{opacity:1;transform:scale(1) translateY(0);}
        }
      `}</style>
    </>
  );
}

function ConvItem({ nombre, sub, imagen, emoji, activa, noLeidos, hora, mini, onClick }: {
  nombre: string; sub: string; imagen?: string | null; emoji?: string;
  activa: boolean; noLeidos: number; hora?: string; mini: boolean; onClick: () => void;
}) {
  return (
    <div onClick={onClick}
      style={{
        display: "flex", alignItems: "center", gap: 8, padding: "8px",
        borderRadius: 10, cursor: "pointer", marginBottom: 2, transition: "all 0.15s",
        background: activa ? "white" : "transparent",
        boxShadow: activa ? "0 2px 6px rgba(0,0,0,0.07)" : "none",
        border: activa ? "1px solid #f0f0f0" : "1px solid transparent"
      }}
      onMouseEnter={e => { if (!activa) (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.7)"; }}
      onMouseLeave={e => { if (!activa) (e.currentTarget as HTMLElement).style.background = "transparent"; }}>
      {emoji ? (
        <div style={{
          width: 36, height: 36, borderRadius: "50%", flexShrink: 0,
          background: "linear-gradient(135deg,#cc1111,#ff6b6b)",
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: 16, boxShadow: "0 2px 6px rgba(204,17,17,0.2)"
        }}>{emoji}</div>
      ) : (
        <Avatar name={nombre} image={imagen} size={36} round />
      )}
      {!mini && (
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <p style={{
              fontSize: 12, fontWeight: 700, color: "#0f0f0f",
              whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis"
            }}>{nombre}</p>
            {hora && <span style={{ fontSize: 9, color: "#bbb", flexShrink: 0, marginLeft: 4 }}>
              {new Date(hora).toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" })}
            </span>}
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 1 }}>
            <p style={{
              fontSize: 11, color: "#9ca3af", whiteSpace: "nowrap",
              overflow: "hidden", textOverflow: "ellipsis", flex: 1,
              fontWeight: noLeidos > 0 ? 600 : 400
            }}>{sub}</p>
            {noLeidos > 0 && (
              <span style={{
                marginLeft: 4, minWidth: 18, height: 18, borderRadius: 99,
                background: "#cc1111", color: "white", fontSize: 9, fontWeight: 800,
                display: "flex", alignItems: "center", justifyContent: "center",
                padding: "0 4px", flexShrink: 0
              }}>
                {noLeidos}
              </span>
            )}
          </div>
        </div>
      )}
      {mini && noLeidos > 0 && (
        <span style={{
          position: "absolute", top: 2, right: 2, width: 8, height: 8,
          borderRadius: "50%", background: "#cc1111"
        }} />
      )}
    </div>
  );
}
