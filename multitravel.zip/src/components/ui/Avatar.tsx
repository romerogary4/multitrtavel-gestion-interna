"use client";

import { useRef, useState } from "react";
import { toast } from "sonner";

interface AvatarProps {
  name: string;
  image?: string | null;
  size?: number;
  round?: boolean;
}

function getGradient(name: string) {
  const gradients = [
    ["#cc1111", "#e52222"],
    ["#2563eb", "#3b82f6"],
    ["#16a34a", "#22c55e"],
    ["#d97706", "#f59e0b"],
    ["#7c3aed", "#8b5cf6"],
    ["#0891b2", "#06b6d4"],
    ["#be185d", "#ec4899"],
    ["#b45309", "#d97706"],
  ];
  const idx = (name.charCodeAt(0) + (name.charCodeAt(1) || 0)) % gradients.length;
  return gradients[idx];
}

export function Avatar({ name, image, size = 36, round = false }: AvatarProps) {
  const initials = name.split(" ").map(n => n.charAt(0)).slice(0, 2).join("").toUpperCase();
  const borderRadius = round ? "50%" : Math.round(size * 0.28);
  const [imgError, setImgError] = useState(false);

  if (image && !imgError) {
    return (
      <img
        src={image}
        alt={name}
        onError={() => setImgError(true)}
        style={{
          width: size, height: size, borderRadius, objectFit: "cover",
          flexShrink: 0, border: "2px solid rgba(255,255,255,0.8)",
          boxShadow: "0 2px 8px rgba(0,0,0,0.12)", display: "block"
        }}
      />
    );
  }

  const [c1, c2] = getGradient(name);
  return (
    <div style={{
      width: size, height: size, borderRadius, flexShrink: 0,
      background: `linear-gradient(135deg, ${c1}, ${c2})`,
      display: "flex", alignItems: "center", justifyContent: "center",
      color: "white", fontWeight: 800, fontSize: Math.round(size * 0.38),
      fontFamily: "var(--font-inter), sans-serif", letterSpacing: "-0.5px",
      boxShadow: "0 2px 8px rgba(0,0,0,0.15)"
    }}>
      {initials}
    </div>
  );
}

// Avatar circular grande con upload — para página de agentes
export function AvatarUpload({ agentId, name, image, onUploaded }: {
  agentId: string; name: string; image?: string | null;
  onUploaded: (url: string) => void;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [localImage, setLocalImage] = useState<string | null | undefined>(image);
  const [imgError, setImgError] = useState(false);

  const initials = name.split(" ").map(n => n.charAt(0)).slice(0, 2).join("").toUpperCase();
  const [c1, c2] = getGradient(name);

  async function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) { toast.error("La imagen no puede superar 5MB"); return; }

    // Preview inmediato
    const reader = new FileReader();
    reader.onload = ev => { setLocalImage(ev.target?.result as string); setImgError(false); };
    reader.readAsDataURL(file);

    setUploading(true);
    const fd = new FormData();
    fd.append("avatar", file);
    try {
      const r = await fetch(`/api/upload-avatar?userId=${agentId}`, { method: "POST", body: fd });
      if (r.ok) {
        const d = await r.json();
        setLocalImage(d.url + "?t=" + Date.now()); // cache bust
        onUploaded(d.url);
        toast.success("Foto actualizada ✓");
      } else {
        toast.error("Error subiendo foto");
        setLocalImage(image); // revert preview
      }
    } catch {
      toast.error("Error de conexión");
      setLocalImage(image);
    } finally {
      setUploading(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  }

  const SIZE = 64;

  return (
    <div
      style={{ position: "relative", width: SIZE, height: SIZE, flexShrink: 0, cursor: "pointer" }}
      onClick={() => !uploading && inputRef.current?.click()}
      title="Cambiar foto"
    >
      {/* Avatar circular */}
      {localImage && !imgError ? (
        <img
          src={localImage}
          alt={name}
          onError={() => { setImgError(true); setLocalImage(null); }}
          style={{
            width: SIZE, height: SIZE, borderRadius: "50%", objectFit: "cover",
            border: "3px solid white", boxShadow: "0 4px 16px rgba(0,0,0,0.15)", display: "block"
          }}
        />
      ) : (
        <div style={{
          width: SIZE, height: SIZE, borderRadius: "50%",
          background: `linear-gradient(135deg, ${c1}, ${c2})`,
          display: "flex", alignItems: "center", justifyContent: "center",
          color: "white", fontWeight: 800, fontSize: 22,
          border: "3px solid white", boxShadow: "0 4px 16px rgba(0,0,0,0.15)"
        }}>
          {initials}
        </div>
      )}

      {/* Overlay hover con cámara */}
      <div style={{
        position: "absolute", inset: 0, borderRadius: "50%",
        background: "rgba(0,0,0,0)", display: "flex", alignItems: "center",
        justifyContent: "center", transition: "background 0.2s",
        fontSize: 20
      }}
        onMouseEnter={e => (e.currentTarget as HTMLElement).style.background = "rgba(0,0,0,0.45)"}
        onMouseLeave={e => (e.currentTarget as HTMLElement).style.background = "rgba(0,0,0,0)"}>
        {uploading ? (
          <div style={{
            width: 18, height: 18, border: "2px solid white",
            borderTopColor: "transparent", borderRadius: "50%",
            animation: "spin 0.8s linear infinite"
          }} />
        ) : (
          <span style={{ opacity: 0, transition: "opacity 0.2s" }}
            onMouseEnter={e => (e.currentTarget as HTMLElement).style.opacity = "1"}
            onMouseLeave={e => (e.currentTarget as HTMLElement).style.opacity = "0"}>
            📷
          </span>
        )}
      </div>

      <input ref={inputRef} type="file" accept="image/jpeg,image/png,image/webp"
        onChange={handleFile} style={{ display: "none" }} />
    </div>
  );
}
