"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { signOut, useSession } from "@/lib/auth-client";
import { useRouter } from "next/navigation";
import { useState, useEffect } from "react";
import { Avatar } from "@/components/ui/Avatar";

const navItems = [
  { href: "/dashboard", label: "Dashboard", emoji: "🏠", adminOnly: false, agenteVisible: true },
  { href: "/clientes", label: "Clientes", emoji: "👥", adminOnly: false, agenteVisible: true },
  { href: "/clientes/nuevo", label: "Nuevo cliente", emoji: "➕", adminOnly: false, agenteVisible: true },

  { href: "/servicios-especiales", label: "Servicios especiales", emoji: "⭐", adminOnly: false, agenteVisible: true },
  { href: "/reportes", label: "Reportes", emoji: "📊", adminOnly: true, agenteVisible: false },
  { href: "/cuadre-diario", label: "Cuadre diario", emoji: "📋", adminOnly: true, agenteVisible: false },
  { href: "/paquetes", label: "Paquetes", emoji: "✈️", adminOnly: true, agenteVisible: false },
  { href: "/admin/agentes", label: "Agentes", emoji: "👤", adminOnly: true, agenteVisible: false },
  { href: "/admin/servicios", label: "Tipos de servicio", emoji: "⭐", adminOnly: true, agenteVisible: false },
];

export function Sidebar() {
  const pathname = usePathname();
  const router = useRouter();
  const { data: session } = useSession();
  const esAdmin = (session?.user as any)?.rol === "administrador";
  const [noLeidosChat, setNoLeidosChat] = useState(0);

  useEffect(() => {
    async function checkChat() {
      try {
        const r = await fetch("/api/chat?tipo=lista");
        if (!r.ok) return;
        const d = await r.json();
        const total = (d.conversaciones || []).reduce((s: number, c: any) => s + (c.noLeidos || 0), 0);
        setNoLeidosChat(total);
      } catch { }
    }
    checkChat(); // Solo al cargar, sin polling continuo
  }, []);
  const userName = session?.user?.name || "Usuario";
  const userRol = (session?.user as any)?.rol || "agente";
  const userImage = session?.user?.image || null;

  async function handleSignOut() {
    await signOut();
    router.push("/auth/login");
  }

  const filtered = navItems.filter(i => esAdmin ? !i.adminOnly || true : i.agenteVisible);
  const mainNav = filtered.filter(i => ["/dashboard", "/clientes", "/clientes/nuevo"].includes(i.href));
  const gestionNav = filtered.filter(i => ["/servicios-especiales", "/reportes"].includes(i.href));
  const adminNav = filtered.filter(i => ["/cuadre-diario", "/paquetes", "/admin/agentes", "/admin/servicios"].includes(i.href));

  return (
    <aside className="sidebar">
      <div className="sidebar-brand">
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{
            width: 46, height: 46, borderRadius: 12, overflow: "hidden",
            background: "#f8f8f8", border: "1.5px solid #ebebeb", flexShrink: 0
          }}>
            <img src="/logo.jpg" alt="Logo"
              style={{ objectFit: "contain", width: "100%", height: "100%" }} />
          </div>
          <div>
            <p style={{
              fontFamily: "var(--font-playfair)", fontWeight: 700, fontSize: 16,
              color: "#0f0f0f", lineHeight: 1.2
            }}>MultiTravel</p>
            <p style={{ fontSize: 12, fontWeight: 600, color: "#cc1111" }}>Cherry Matute</p>
          </div>
        </div>
      </div>

      <nav style={{ flex: 1, overflowY: "auto", paddingBottom: 8 }}>
        <p className="nav-section-label">Principal</p>
        {mainNav.map(i => <NavItem key={i.href} item={i} pathname={pathname} badge={undefined} />)}

        {gestionNav.length > 0 && (
          <>
            <p className="nav-section-label">Gestión</p>
            {gestionNav.map(i => <NavItem key={i.href} item={i} pathname={pathname} />)}
          </>
        )}

        {esAdmin && adminNav.length > 0 && (
          <>
            <p className="nav-section-label">Administración</p>
            {adminNav.map(i => <NavItem key={i.href} item={i} pathname={pathname} />)}
          </>
        )}
      </nav>

      <div style={{ padding: "12px", borderTop: "1px solid #f0f0f0" }}>
        <div style={{ background: "#fafafa", borderRadius: 14, padding: "12px", border: "1px solid #ebebeb" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
            <Avatar name={userName} image={userImage} size={38} />
            <div style={{ overflow: "hidden", flex: 1 }}>
              <p style={{
                fontSize: 13, fontWeight: 600, color: "#111", whiteSpace: "nowrap",
                overflow: "hidden", textOverflow: "ellipsis"
              }}>{userName}</p>
              <p style={{ fontSize: 11, color: "#9ca3af", textTransform: "capitalize" }}>{userRol}</p>
            </div>
          </div>
          <button onClick={handleSignOut}
            style={{
              width: "100%", textAlign: "left", padding: "7px 10px", borderRadius: 8,
              fontSize: 12, color: "#9ca3af", background: "transparent", border: "none",
              cursor: "pointer", fontFamily: "inherit", transition: "all 0.15s"
            }}
            onMouseEnter={e => {
              (e.currentTarget as HTMLElement).style.background = "#fee2e2";
              (e.currentTarget as HTMLElement).style.color = "#cc1111";
            }}
            onMouseLeave={e => {
              (e.currentTarget as HTMLElement).style.background = "transparent";
              (e.currentTarget as HTMLElement).style.color = "#9ca3af";
            }}>
            ← Cerrar sesión
          </button>
        </div>
      </div>
    </aside>
  );
}

function NavItem({ item, pathname, badge }: { item: typeof navItems[0]; pathname: string; badge?: number }) {
  const isActive = pathname === item.href ||
    (item.href !== "/clientes" && pathname.startsWith(item.href + "/"));
  return (
    <Link href={item.href} className={`nav-item ${isActive ? "active" : ""}`}
      style={{ position: "relative" }}>
      <span style={{ fontSize: 15 }}>{item.emoji}</span>
      <span style={{ flex: 1 }}>{item.label}</span>
      {badge && badge > 0 && (
        <span style={{
          minWidth: 18, height: 18, borderRadius: 99, background: "#cc1111",
          color: "white", fontSize: 10, fontWeight: 700, display: "flex",
          alignItems: "center", justifyContent: "center", padding: "0 5px"
        }}>
          {badge}
        </span>
      )}
      {isActive && !badge && <span className="nav-dot" />}
    </Link>
  );
}