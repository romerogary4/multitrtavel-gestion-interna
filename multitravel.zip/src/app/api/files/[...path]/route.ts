import { NextRequest, NextResponse } from "next/server";
import path from "path";
import fs from "fs/promises";
import { getServerSession } from "@/lib/auth-helpers";

const UPLOAD_DIR = process.env.UPLOAD_DIR || "./uploads";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ path: string[] }> }
) {
  // Verificar autenticación
  const session = await getServerSession();
  if (!session) {
    return new NextResponse("No autorizado", { status: 401 });
  }

  const { path: pathParts } = await params;
  const filePath = path.join(UPLOAD_DIR, ...pathParts);

  // Seguridad: evitar path traversal
  const resolvedPath = path.resolve(filePath);
  const resolvedUploadDir = path.resolve(UPLOAD_DIR);
  if (!resolvedPath.startsWith(resolvedUploadDir)) {
    return new NextResponse("Acceso denegado", { status: 403 });
  }

  try {
    const file = await fs.readFile(resolvedPath);
    const ext = path.extname(resolvedPath).toLowerCase();
    
    const contentTypes: Record<string, string> = {
      ".pdf": "application/pdf",
      ".jpg": "image/jpeg",
      ".jpeg": "image/jpeg",
      ".png": "image/png",
      ".webp": "image/webp",
    };
    
    const contentType = contentTypes[ext] || "application/octet-stream";
    
    return new NextResponse(file, {
      headers: {
        "Content-Type": contentType,
        "Cache-Control": "private, max-age=3600",
      },
    });
  } catch {
    return new NextResponse("Archivo no encontrado", { status: 404 });
  }
}
