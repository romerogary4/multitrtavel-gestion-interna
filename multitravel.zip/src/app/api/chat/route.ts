import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { conversacion, mensaje, user } from "@/db/schema";
import { getServerSession } from "@/lib/auth-helpers";
import type { AppSession } from "@/types";
import { eq, and, desc, sql, or } from "drizzle-orm";

// GET /api/chat?tipo=general|privada&conUsuario=userId&desde=isoDate
export async function GET(request: NextRequest) {
  const session = await getServerSession() as AppSession | null;
  if (!session) return NextResponse.json({ error: "No autorizado" }, { status: 401 });

  const { searchParams } = new URL(request.url);
  const tipo = searchParams.get("tipo");
  const conUsuario = searchParams.get("conUsuario");
  const desde = searchParams.get("desde"); // para polling incremental

  // ── Listar todas las conversaciones del usuario ──────────────────────────
  if (tipo === "lista") {
    // Una sola query optimizada con subqueries en vez de N queries paralelas
    const [convData, usuariosData] = await Promise.all([
      db.execute(sql`
        SELECT
          c.id, c.tipo, c.participantes,
          (SELECT m.contenido FROM mensaje m WHERE m.conversacion_id = c.id ORDER BY m.creado_en DESC LIMIT 1) as ultimo_contenido,
          (SELECT m.creado_en FROM mensaje m WHERE m.conversacion_id = c.id ORDER BY m.creado_en DESC LIMIT 1) as ultimo_creado_en,
          (SELECT m.autor_id FROM mensaje m WHERE m.conversacion_id = c.id ORDER BY m.creado_en DESC LIMIT 1) as ultimo_autor_id,
          (SELECT m.leido_por FROM mensaje m WHERE m.conversacion_id = c.id ORDER BY m.creado_en DESC LIMIT 1) as ultimo_leido_por,
          (SELECT COUNT(*) FROM mensaje m WHERE m.conversacion_id = c.id
            AND m.autor_id != ${session.user.id}
            AND NOT (m.leido_por @> ${JSON.stringify([session.user.id])}::jsonb)
          ) as no_leidos
        FROM conversacion c
        WHERE c.tipo = 'general'
          OR (c.tipo = 'privada' AND c.participantes @> ${JSON.stringify([session.user.id])}::jsonb)
      `),
      db.select({ id: user.id, name: user.name, image: user.image })
        .from(user).where(sql`${user.activo} = true`),
    ]);

    const resultado = (convData.rows as any[]).map(row => ({
      id: row.id, tipo: row.tipo, participantes: row.participantes,
      ultimoMensaje: row.ultimo_contenido ? {
        contenido: row.ultimo_contenido,
        creadoEn: row.ultimo_creado_en,
        autorId: row.ultimo_autor_id,
        leidoPor: row.ultimo_leido_por,
      } : null,
      noLeidos: Number(row.no_leidos),
    }));

    return NextResponse.json({ conversaciones: resultado, usuarios: usuariosData });
  }

  // ── Mensajes de una conversación ─────────────────────────────────────────
  let convId: string | null = null;

  if (tipo === "general") {
    const [general] = await db.select({ id: conversacion.id })
      .from(conversacion).where(eq(conversacion.tipo, "general"));
    convId = general?.id || null;
  } else if (conUsuario) {
    // Buscar o crear conversación privada
    const privadas = await db.select().from(conversacion).where(
      and(
        eq(conversacion.tipo, "privada"),
        sql`${conversacion.participantes} @> ${JSON.stringify([session.user.id, conUsuario])}::jsonb`,
        sql`jsonb_array_length(${conversacion.participantes}) = 2`
      )
    );
    convId = privadas[0]?.id || null;
  }

  if (!convId) return NextResponse.json({ mensajes: [], convId: null });

  // Marcar como leídos
  await db.execute(sql`
    UPDATE mensaje SET leido_por = leido_por || ${JSON.stringify([session.user.id])}::jsonb
    WHERE conversacion_id = ${convId}
      AND autor_id != ${session.user.id}
      AND NOT (leido_por @> ${JSON.stringify([session.user.id])}::jsonb)
  `);

  const whereCond = desde
    ? and(eq(mensaje.conversacionId, convId), sql`${mensaje.creadoEn} > ${desde}::timestamptz`)
    : eq(mensaje.conversacionId, convId);

  const mensajes = await db.select({
    id: mensaje.id, contenido: mensaje.contenido,
    autorId: mensaje.autorId, leidoPor: mensaje.leidoPor, creadoEn: mensaje.creadoEn,
    autor: { name: user.name, image: user.image },
  }).from(mensaje)
    .leftJoin(user, eq(mensaje.autorId, user.id))
    .where(whereCond)
    .orderBy(mensaje.creadoEn)
    .limit(100);

  return NextResponse.json({ mensajes, convId });
}

// POST /api/chat — enviar mensaje
export async function POST(request: NextRequest) {
  const session = await getServerSession() as AppSession | null;
  if (!session) return NextResponse.json({ error: "No autorizado" }, { status: 401 });

  const body = await request.json();
  const { contenido, tipo, conUsuario } = body;

  if (!contenido?.trim()) return NextResponse.json({ error: "Mensaje vacío" }, { status: 400 });

  let convId: string;

  if (tipo === "general") {
    const [general] = await db.select({ id: conversacion.id })
      .from(conversacion).where(eq(conversacion.tipo, "general"));
    if (!general) return NextResponse.json({ error: "Sala general no encontrada" }, { status: 404 });
    convId = general.id;
  } else if (conUsuario) {
    // Buscar conversación privada existente
    const privadas = await db.select().from(conversacion).where(
      and(
        eq(conversacion.tipo, "privada"),
        sql`${conversacion.participantes} @> ${JSON.stringify([session.user.id, conUsuario])}::jsonb`,
        sql`jsonb_array_length(${conversacion.participantes}) = 2`
      )
    );
    if (privadas.length > 0) {
      convId = privadas[0].id;
    } else {
      const [nueva] = await db.insert(conversacion).values({
        tipo: "privada",
        participantes: [session.user.id, conUsuario] as any,
      }).returning();
      convId = nueva.id;
    }
  } else {
    return NextResponse.json({ error: "conUsuario requerido" }, { status: 400 });
  }

  const [nuevo] = await db.insert(mensaje).values({
    conversacionId: convId,
    autorId: session.user.id,
    contenido: contenido.trim(),
    leidoPor: [session.user.id] as any,
  }).returning();

  return NextResponse.json({ ok: true, mensaje: nuevo, convId });
}