"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import { useSession } from "@/lib/auth-client";
import { Avatar } from "@/components/ui/Avatar";

interface Usuario { id: string; name: string; image?: string | null; }
interface MensajeData {
  id: string; contenido: string; autorId: string; leidoPor: string[];
  creadoEn: string; autor?: { name: string; image?: string | null };
}
interface ConvData {
  id: string; tipo: string; participantes: string[];
  ultimoMensaje?: { contenido: string; creadoEn: string; autorId: string; leidoPor: string[] } | null;
  noLeidos: number;
}

function formatHora(iso: string) {
  return new Date(iso).toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" });
}

function formatFechaSep(iso: string) {
  const d = new Date(iso);
  const hoy = new Date(); hoy.setHours(0, 0, 0, 0);
  const ayer = new Date(hoy); ayer.setDate(hoy.getDate() - 1);
  const fecha = new Date(d); fecha.setHours(0, 0, 0, 0);
  if (fecha.getTime() === hoy.getTime()) return "Hoy";
  if (fecha.getTime() === ayer.getTime()) return "Ayer";
  return d.toLocaleDateString("es-ES", { weekday: "long", day: "numeric", month: "long" });
}

function agruparPorFecha(mensajes: MensajeData[]) {
  const grupos: { fecha: string; items: MensajeData[] }[] = [];
  mensajes.forEach(m => {
    const d = new Date(m.creadoEn); d.setHours(0, 0, 0, 0);
    const key = d.toISOString();
    const ultimo = grupos[grupos.length - 1];
    if (ultimo && ultimo.fecha === key) ultimo.items.push(m);
    else grupos.push({ fecha: key, items: [m] });
  });
  return grupos;
}

export default function ChatPage() {
  const { data: session } = useSession();
  const miId = (session?.user as any)?.id;

  const [usuarios, setUsuarios] = useState<Usuario[]>([]);
  const [conversaciones, setConversaciones] = useState<ConvData[]>([]);
  const [activa, setActiva] = useState<{ tipo: "general" | "privada"; conUsuario?: string }>(
    { tipo: "general" }
  );
  const [mensajes, setMensajes] = useState<MensajeData[]>([]);
  const [texto, setTexto] = useState("");
  const [enviando, setEnviando] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const ultimoRef = useRef<string | null>(null);
  const pollingRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const mensajesLen = useRef(0);
  mensajesLen.current = mensajes.length;

  const cargarLista = useCallback(async () => {
    const r = await fetch("/api/chat?tipo=lista");
    if (!r.ok) return;
    const d = await r.json();
    setConversaciones(d.conversaciones || []);
    setUsuarios(d.usuarios || []);
  }, []);

  const cargarMensajes = useCallback(async (resetear = false) => {
    const params = new URLSearchParams();
    if (activa.tipo === "general") params.set("tipo", "general");
    else if (activa.conUsuario) params.set("conUsuario", activa.conUsuario);
    else return;
    if (!resetear && ultimoRef.current && mensajesLen.current > 0) {
      params.set("desde", ultimoRef.current);
    }
    const r = await fetch(`/api/chat?${params}`);
    if (!r.ok) return;
    const d = await r.json();
    if (resetear) {
      setMensajes(d.mensajes || []);
    } else if (d.mensajes?.length > 0) {
      setMensajes(prev => {
        const ids = new Set(prev.map((m: MensajeData) => m.id));
        const nuevos = d.mensajes.filter((m: MensajeData) => !ids.has(m.id));
        return nuevos.length > 0 ? [...prev, ...nuevos] : prev;
      });
    }
    if (d.mensajes?.length > 0) {
      ultimoRef.current = d.mensajes[d.mensajes.length - 1].creadoEn;
    }
    cargarLista();
  }, [activa.tipo, activa.conUsuario, cargarLista]);

  useEffect(() => {
    setMensajes([]);
    ultimoRef.current = null;
    cargarMensajes(true);
    if (pollingRef.current) clearInterval(pollingRef.current);
    pollingRef.current = setInterval(() => cargarMensajes(false), 3000);
    return () => { if (pollingRef.current) clearInterval(pollingRef.current); };
  }, [activa.tipo, activa.conUsuario]);

  useEffect(() => { cargarLista(); }, []);
  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [mensajes]);

  async function enviar() {
    if (!texto.trim() || enviando) return;
    setEnviando(true);
    const body: any = { contenido: texto, tipo: activa.tipo };
    if (activa.conUsuario) body.conUsuario = activa.conUsuario;
    const r = await fetch("/api/chat", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body)
    });
    if (r.ok) { setTexto(""); await cargarMensajes(false); }
    setEnviando(false);
  }

  function handleKey(e: React.KeyboardEvent) {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); enviar(); }
  }

  const getUsuario = (id: string) => usuarios.find(u => u.id === id);
  const convGeneral = conversaciones.find(c => c.tipo === "general");
  const nombreActiva = activa.tipo === "general" ? "Sala general" : getUsuario(activa.conUsuario || "")?.name || "";
  const grupos = agruparPorFecha(mensajes);

  return (
    <div style={{
      display: "flex", height: "calc(100vh - 72px)", borderRadius: 20, overflow: "hidden",
      border: "1px solid #ebebeb", boxShadow: "0 8px 40px rgba(0,0,0,0.08)", background: "white"
    }}>

      {/* ── Sidebar ── */}
      <div style={{
        width: 300, borderRight: "1px solid #f0f0f0", display: "flex",
        flexDirection: "column", background: "#f8f8f8"
      }}>
        <div style={{ padding: "20px 20px 14px", borderBottom: "1px solid #ebebeb" }}>
          <h2 style={{
            fontFamily: "var(--font-playfair)", fontWeight: 800, fontSize: 19,
            color: "#0f0f0f", display: "flex", alignItems: "center", gap: 8
          }}>
            <span style={{ width: 3, height: 20, background: "#cc1111", borderRadius: 4, display: "block" }} />
            Mensajes
          </h2>
        </div>
        <div style={{ flex: 1, overflowY: "auto", padding: "8px 12px" }}>
          <p style={{
            fontSize: 10, fontWeight: 700, color: "#bbb", textTransform: "uppercase",
            letterSpacing: "0.1em", padding: "4px 6px 6px"
          }}>General</p>
          <SidebarItem nombre="Sala general"
            sub={convGeneral?.ultimoMensaje?.contenido || "Sin mensajes aún"}
            emoji="🌐" activa={activa.tipo === "general"}
            noLeidos={convGeneral?.noLeidos || 0}
            hora={convGeneral?.ultimoMensaje?.creadoEn}
            onClick={() => setActiva({ tipo: "general" })} />

          <p style={{
            fontSize: 10, fontWeight: 700, color: "#bbb", textTransform: "uppercase",
            letterSpacing: "0.1em", padding: "12px 6px 6px"
          }}>Directos</p>
          {usuarios.filter(u => u.id !== miId).map(u => {
            const conv = conversaciones.find(c =>
              c.tipo === "privada" && c.participantes.includes(u.id) && c.participantes.includes(miId)
            );
            return (
              <SidebarItem key={u.id} nombre={u.name}
                sub={conv?.ultimoMensaje?.contenido || "Iniciar conversación"}
                imagen={u.image} activa={activa.tipo === "privada" && activa.conUsuario === u.id}
                noLeidos={conv?.noLeidos || 0} hora={conv?.ultimoMensaje?.creadoEn}
                onClick={() => setActiva({ tipo: "privada", conUsuario: u.id })} />
            );
          })}
        </div>
      </div>

      {/* ── Panel mensajes ── */}
      <div style={{ flex: 1, display: "flex", flexDirection: "column" }}>
        {/* Header */}
        <div style={{
          padding: "14px 20px", borderBottom: "1px solid #f0f0f0", background: "white",
          display: "flex", alignItems: "center", gap: 12, boxShadow: "0 1px 8px rgba(0,0,0,0.04)"
        }}>
          {activa.tipo === "general" ? (
            <div style={{
              width: 44, height: 44, borderRadius: "50%",
              background: "linear-gradient(135deg,#cc1111,#ff6b6b)",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 20, boxShadow: "0 4px 12px rgba(204,17,17,0.25)"
            }}>🌐</div>
          ) : (
            <Avatar name={getUsuario(activa.conUsuario || "")?.name || "?"}
              image={getUsuario(activa.conUsuario || "")?.image} size={44} round />
          )}
          <div>
            <p style={{ fontWeight: 700, fontSize: 16, color: "#0f0f0f" }}>{nombreActiva}</p>
            <p style={{ fontSize: 12, color: "#9ca3af", marginTop: 1 }}>
              {activa.tipo === "general" ? `${usuarios.length} participantes` : "Mensaje directo · privado"}
            </p>
          </div>
        </div>

        {/* Mensajes */}
        <div style={{
          flex: 1, overflowY: "auto", padding: "20px 24px",
          backgroundImage: "radial-gradient(#e8e8e8 1px, transparent 1px)",
          backgroundSize: "24px 24px", backgroundColor: "#fdfdfd"
        }}>

          {mensajes.length === 0 && (
            <div style={{
              display: "flex", alignItems: "center", justifyContent: "center",
              flexDirection: "column", gap: 10, color: "#9ca3af", paddingTop: 80
            }}>
              <div style={{
                width: 64, height: 64, borderRadius: "50%", background: "#f0f0f0",
                display: "flex", alignItems: "center", justifyContent: "center", fontSize: 28
              }}>💬</div>
              <p style={{ fontSize: 14, fontWeight: 500 }}>Sin mensajes aún</p>
              <p style={{ fontSize: 12, color: "#bbb" }}>¡Sé el primero en escribir!</p>
            </div>
          )}

          {grupos.map((grupo) => (
            <div key={grupo.fecha}>
              {/* Separador fecha */}
              <div style={{ display: "flex", alignItems: "center", gap: 12, margin: "16px 0 12px" }}>
                <div style={{ flex: 1, height: 1, background: "#e0e0e0" }} />
                <span style={{
                  fontSize: 11, fontWeight: 600, color: "#9ca3af",
                  background: "white", padding: "4px 14px", borderRadius: 99,
                  border: "1px solid #e8e8e8", whiteSpace: "nowrap",
                  boxShadow: "0 1px 4px rgba(0,0,0,0.05)"
                }}>
                  {formatFechaSep(grupo.fecha)}
                </span>
                <div style={{ flex: 1, height: 1, background: "#e0e0e0" }} />
              </div>

              {grupo.items.map((m, i) => {
                const esMio = m.autorId === miId;
                const mismoAntes = i > 0 && grupo.items[i - 1].autorId === m.autorId;
                const mismoDespues = i < grupo.items.length - 1 && grupo.items[i + 1].autorId === m.autorId;
                const todosLeidos = activa.tipo === "privada" && (m.leidoPor?.length || 0) > 1;

                const brMio = mismoAntes && mismoDespues ? "18px 4px 4px 18px"
                  : mismoAntes ? "18px 4px 18px 18px"
                    : mismoDespues ? "18px 18px 4px 18px"
                      : "18px 18px 4px 18px";

                const brOtro = mismoAntes && mismoDespues ? "4px 18px 18px 4px"
                  : mismoAntes ? "4px 18px 18px 18px"
                    : mismoDespues ? "4px 18px 4px 4px"
                      : "4px 18px 18px 18px";

                return (
                  <div key={m.id} style={{
                    display: "flex", flexDirection: "column",
                    alignItems: esMio ? "flex-end" : "flex-start",
                    marginBottom: mismoDespues ? 2 : 8
                  }}>

                    {!esMio && !mismoAntes && activa.tipo === "general" && (
                      <span style={{
                        fontSize: 12, fontWeight: 700, color: "#555",
                        marginBottom: 4, marginLeft: 42
                      }}>
                        {m.autor?.name}
                      </span>
                    )}

                    <div style={{
                      display: "flex", alignItems: "flex-end", gap: 8,
                      flexDirection: esMio ? "row-reverse" : "row"
                    }}>
                      {!esMio && (
                        <div style={{ width: 34, flexShrink: 0 }}>
                          {!mismoDespues && (
                            <Avatar name={m.autor?.name || "?"} image={m.autor?.image} size={34} round />
                          )}
                        </div>
                      )}

                      <div style={{ maxWidth: "65%" }}>
                        <div style={{
                          padding: "10px 14px",
                          borderRadius: esMio ? brMio : brOtro,
                          background: esMio ? "linear-gradient(135deg,#cc1111,#e53333)" : "white",
                          color: esMio ? "white" : "#111",
                          border: esMio ? "none" : "1px solid #eee",
                          boxShadow: esMio
                            ? "0 4px 12px rgba(204,17,17,0.2)"
                            : "0 2px 8px rgba(0,0,0,0.06)",
                          fontSize: 14, lineHeight: 1.55, wordBreak: "break-word",
                        }}>
                          {m.contenido}
                        </div>
                        {!mismoDespues && (
                          <div style={{
                            display: "flex", alignItems: "center", gap: 4,
                            marginTop: 3, fontSize: 10, color: "#bbb",
                            justifyContent: esMio ? "flex-end" : "flex-start"
                          }}>
                            <span>{formatHora(m.creadoEn)}</span>
                            {esMio && (
                              <span style={{ color: todosLeidos ? "#3b82f6" : "#ccc", fontWeight: 700, fontSize: 12 }}>
                                {todosLeidos ? "✓✓" : "✓"}
                              </span>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ))}
          <div ref={bottomRef} />
        </div>

        {/* Input */}
        <div style={{
          padding: "12px 16px", borderTop: "1px solid #f0f0f0", background: "white",
          display: "flex", gap: 10, alignItems: "flex-end"
        }}>
          <textarea value={texto} onChange={e => setTexto(e.target.value)} onKeyDown={handleKey}
            placeholder="Escribe un mensaje... (Enter para enviar)" rows={1}
            style={{
              flex: 1, resize: "none", border: "1.5px solid #e0e0e8", borderRadius: 20,
              padding: "11px 16px", fontSize: 14, fontFamily: "inherit", outline: "none",
              lineHeight: 1.5, maxHeight: 120, overflowY: "auto", background: "#fafafa",
              transition: "all 0.15s", boxSizing: "border-box"
            }}
            onFocus={e => {
              (e.target as HTMLElement).style.borderColor = "#cc1111";
              (e.target as HTMLElement).style.boxShadow = "0 0 0 3px rgba(204,17,17,0.08)";
              (e.target as HTMLElement).style.background = "white";
            }}
            onBlur={e => {
              (e.target as HTMLElement).style.borderColor = "#e0e0e8";
              (e.target as HTMLElement).style.boxShadow = "none";
              (e.target as HTMLElement).style.background = "#fafafa";
            }} />
          <button onClick={enviar} disabled={enviando || !texto.trim()}
            style={{
              width: 46, height: 46, borderRadius: "50%", flexShrink: 0,
              background: texto.trim() ? "linear-gradient(135deg,#cc1111,#e53333)" : "#f0f0f0",
              border: "none", cursor: texto.trim() ? "pointer" : "default",
              display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18,
              transition: "all 0.2s",
              boxShadow: texto.trim() ? "0 4px 12px rgba(204,17,17,0.3)" : "none",
              transform: texto.trim() ? "scale(1.05)" : "scale(1)"
            }}>
            {enviando
              ? <div style={{
                width: 16, height: 16, border: "2px solid white",
                borderTopColor: "transparent", borderRadius: "50%",
                animation: "spin 0.8s linear infinite"
              }} />
              : <span style={{ marginLeft: 2 }}>➤</span>
            }
          </button>
        </div>
      </div>
    </div>
  );
}

function SidebarItem({ nombre, sub, imagen, emoji, activa, noLeidos, hora, onClick }: {
  nombre: string; sub: string; imagen?: string | null; emoji?: string;
  activa: boolean; noLeidos: number; hora?: string; onClick: () => void;
}) {
  return (
    <div onClick={onClick}
      style={{
        display: "flex", alignItems: "center", gap: 10, padding: "10px",
        borderRadius: 12, cursor: "pointer", marginBottom: 2, transition: "all 0.15s",
        background: activa ? "white" : "transparent",
        boxShadow: activa ? "0 2px 8px rgba(0,0,0,0.08)" : "none",
        border: activa ? "1px solid #f0f0f0" : "1px solid transparent"
      }}
      onMouseEnter={e => { if (!activa) (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.7)"; }}
      onMouseLeave={e => { if (!activa) (e.currentTarget as HTMLElement).style.background = "transparent"; }}>
      {emoji ? (
        <div style={{
          width: 40, height: 40, borderRadius: "50%", flexShrink: 0,
          background: "linear-gradient(135deg,#cc1111,#ff6b6b)",
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: 18, boxShadow: "0 2px 8px rgba(204,17,17,0.2)"
        }}>{emoji}</div>
      ) : (
        <Avatar name={nombre} image={imagen} size={40} round />
      )}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <p style={{
            fontSize: 13, fontWeight: 700, color: "#0f0f0f",
            whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis"
          }}>{nombre}</p>
          {hora && <span style={{ fontSize: 10, color: "#bbb", flexShrink: 0, marginLeft: 6 }}>
            {new Date(hora).toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" })}
          </span>}
        </div>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 2 }}>
          <p style={{
            fontSize: 12, color: "#9ca3af", whiteSpace: "nowrap",
            overflow: "hidden", textOverflow: "ellipsis", flex: 1,
            fontWeight: noLeidos > 0 ? 600 : 400
          }}>{sub}</p>
          {noLeidos > 0 && (
            <span style={{
              marginLeft: 6, minWidth: 20, height: 20, borderRadius: 99,
              background: "#cc1111", color: "white", fontSize: 10, fontWeight: 800,
              display: "flex", alignItems: "center", justifyContent: "center",
              padding: "0 6px", flexShrink: 0, boxShadow: "0 2px 6px rgba(204,17,17,0.4)"
            }}>
              {noLeidos}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}
