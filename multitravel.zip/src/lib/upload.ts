import path from "path";
import fs from "fs/promises";
import { randomUUID } from "crypto";

const UPLOAD_DIR = process.env.UPLOAD_DIR || "./uploads";

export async function ensureUploadDir(subdir: string = "") {
  const dir = path.join(UPLOAD_DIR, subdir);
  await fs.mkdir(dir, { recursive: true });
  return dir;
}

export async function saveFile(
  buffer: Buffer,
  originalName: string,
  subdir: string = "general"
): Promise<{ rutaArchivo: string; nombreOriginal: string; tamano: number }> {
  const dir = await ensureUploadDir(subdir);
  const ext = path.extname(originalName).toLowerCase();
  const fileName = `${randomUUID()}${ext}`;
  const filePath = path.join(dir, fileName);
  
  await fs.writeFile(filePath, buffer);
  
  // Ruta relativa para guardar en DB (desde UPLOAD_DIR)
  const rutaRelativa = path.join(subdir, fileName);
  
  return {
    rutaArchivo: rutaRelativa,
    nombreOriginal: originalName,
    tamano: buffer.length,
  };
}

export async function deleteFile(rutaArchivo: string): Promise<void> {
  try {
    const filePath = path.join(UPLOAD_DIR, rutaArchivo);
    await fs.unlink(filePath);
  } catch {
    // Ignorar si el archivo no existe
  }
}

export function getFileUrl(rutaArchivo: string): string {
  return `/api/files/${rutaArchivo}`;
}

export const ALLOWED_IMAGE_TYPES = [
  "image/jpeg",
  "image/jpg", 
  "image/png",
  "image/webp",
];

export const ALLOWED_DOC_TYPES = [
  "application/pdf",
  "image/jpeg",
  "image/jpg",
  "image/png",
];

export const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB

export function validateFile(
  mimeType: string,
  size: number,
  allowedTypes: string[]
): { valid: boolean; error?: string } {
  if (!allowedTypes.includes(mimeType)) {
    return {
      valid: false,
      error: `Tipo de archivo no permitido. Permitidos: ${allowedTypes.join(", ")}`,
    };
  }
  if (size > MAX_FILE_SIZE) {
    return {
      valid: false,
      error: "El archivo supera el tamaño máximo de 10MB",
    };
  }
  return { valid: true };
}
