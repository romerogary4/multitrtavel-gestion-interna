import { createAuthClient } from "better-auth/react";

export const authClient = createAuthClient({
  baseURL: process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000",
});

export const { signIn, signOut, signUp, useSession, getSession } = authClient;

// Tipo extendido para usar en componentes cliente
export type SessionUser = {
  id: string;
  name: string;
  email: string;
  rol: string;
  activo: boolean;
  image?: string | null;
};
